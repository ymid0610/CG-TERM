#pragma once
#include <gl/glew.h>
#include <gl/glm/glm.hpp>
#include <gl/glm/ext.hpp>
#include <vector>
#include "ReadObjFile.h"

// ���� ���� ���
#define STATE_OUTSIDE 0
#define STATE_ENTERING 1
#define STATE_HIDDEN 2
#define STATE_EXITING 3

class Wardrobe
{
public:
    Wardrobe(float x, float z, float rot);
    ~Wardrobe();

    void Update(glm::vec3& playerPos, float& cameraAngle, float& pitch, int& viewMode, bool& isFlashlightOn);
    void Draw(GLuint shaderID, const Model& model);
    int TryInteract(glm::vec3 playerPos);
    int GetState() { return currentState; }

    glm::vec3 GetPos() const { return glm::vec3(posX, -1.0f, posZ); }

private:
    void DrawBox(GLuint shaderID, const Model& model, glm::mat4 modelMat, glm::vec3 color);

    float posX, posZ;
    float rotation; // ������ ȸ�� ���� (Y�� ����)

    float zWidth;
    float yBase;

    // �ִϸ��̼� ����
    float currentDoorAngle;
    float targetAngle;
    float doorSpeed;
    int currentState;
};