#include "TestGhost.h"
#include <iostream>
#include <cmath> // sin, cos, atan2
#include <queue>
#include <unordered_map>
#include <random>

Ghost::Ghost(glm::vec3 startPos) {
    pos = startPos;
    baseHeight = startPos.y;
    rotY = 0.0f;
    speed = 0.11f; // �̵� �ӵ�

    floatTime = 0.0f;
    wobbleTime = 0.0f;

    // ���� ����
    baseColor = glm::vec3(0.1f, 0.3f, 0.5f);
}

void Ghost::DrawBox(GLuint shaderID, const Model& model, glm::mat4 modelMat, glm::vec3 color) {
    GLint modelLoc = glGetUniformLocation(shaderID, "model");
    GLint faceColorLoc = glGetUniformLocation(shaderID, "faceColor");

    glEnable(GL_BLEND);

    // ���� ȥ��
    glBlendFunc(GL_ONE, GL_ONE);

    // ���� ���� ���� - ���� ������ �޸��� �������� �ʰ� ���� ���̰� ��
    glDepthMask(GL_FALSE);

    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(modelMat));
    glUniform3f(faceColorLoc, color.r, color.g, color.b);

    if (model.face_count > 0)
        glDrawElements(GL_TRIANGLES, model.face_count * 3, GL_UNSIGNED_INT, 0);

    // ���� ����- ���� ��ü�� ���� ������ ������� ��������
    glDepthMask(GL_TRUE);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); // �⺻ ���������� ����
    glDisable(GL_BLEND);
}

bool Ghost::Update(glm::vec3 playerPos, MazeMap& maze, bool playerIsHide) {

    // �÷��̾� �浹ó��
	if (IsCollideWithPlayer(pos, playerPos)) {
		// �浹 �� ���� ������ġ�� �̵�
		pos = GetRandomPathPosition(maze, MAP_SIZE, baseHeight);
		return true; // �浹 �߻�
	}

    // ���� y��ġ ����
    if (state == NORMAL) targetY = pos.y;

    if (playerIsHide) {
        // ���� ���� ���� �̵� ����
        if (state == NORMAL || state == GOING_DOWN) state = GOING_UP;
    }
    else {
        // ������ ���� �Ʒ��� �̵� ����
        if (state == WAITING || state == GOING_UP) state = GOING_DOWN;
    }

    // ���º� y�� �̵� ó��
    if (state == GOING_UP) {
        pos.y += yMoveSpeed;
        if (pos.y >= hideY) {
            pos.y = hideY;
            state = WAITING;
        }
        return false;
    }
    if (state == WAITING) {
        // ������ ���, ���� ����
        return false;
    }
    if (state == GOING_DOWN) {
        pos.y -= yMoveSpeed;
        if (pos.y <= targetY) {
            pos.y = targetY;
            state = NORMAL;
        }
        return false;
    }

    // NORMAL ���¿����� �÷��̾� ����
    int mapSize = MAP_SIZE;
    auto path = FindPath(maze, pos, playerPos, mapSize);
    if (!path.empty()) {
        int nextIdx = (path.size() > 1) ? 1 : 0;
        int nextGridZ = path[nextIdx].first;
        int nextGridX = path[nextIdx].second;
        float targetX = nextGridX * WALL_SIZE;
        float targetZ = nextGridZ * WALL_SIZE;
        glm::vec3 direction = glm::normalize(glm::vec3(targetX, pos.y, targetZ) - pos);

        float nextX = pos.x + direction.x * speed;
        float nextZ = pos.z + direction.z * speed;

        if (!maze.CheckCollision(nextX, pos.z)) {
            pos.x = nextX;
        }
        if (!maze.CheckCollision(pos.x, nextZ)) {
            pos.z = nextZ;
        }
        rotY = glm::degrees(atan2(direction.x, direction.z));
    }
    else {
		// �÷��̾�� ��ΰ� ������ �÷��̾ ���� �ٷ� �̵�
		glm::vec3 direction = glm::normalize(playerPos - pos);
		float nextX = pos.x + direction.x * speed;
		float nextZ = pos.z + direction.z * speed;
        if (!maze.CheckCollision(nextX, pos.z)) {
            pos.x = nextX;
        }
		if (!maze.CheckCollision(pos.x, nextZ)) {
			pos.z = nextZ;
		}
		rotY = glm::degrees(atan2(direction.x, direction.z));
    }

    // �յ� �ߴ� �ִϸ��̼�
    floatTime += 0.05f;
    wobbleTime += 0.1f;
    pos.y = baseHeight + sin(floatTime) * 0.3f; // ���Ʒ� ������

	return false; // �浹 ����
}

void Ghost::Draw(GLuint shaderID, const Model& model) {
    glm::mat4 bodyMat = glm::mat4(1.0f);
    bodyMat = glm::translate(bodyMat, pos);
    bodyMat = glm::rotate(bodyMat, glm::radians(rotY), glm::vec3(0.0f, 1.0f, 0.0f));

    // 1. �Ӹ�
    glm::mat4 headMat = glm::translate(bodyMat, glm::vec3(0.0f, 0.8f, 0.0f));
    glm::mat4 headScale = glm::scale(headMat, glm::vec3(0.6f, 0.6f, 0.6f));
    // �Ӹ��� ���� ��� (�����ϰ�)
    DrawBox(shaderID, model, headScale, baseColor);

    // �� (������ ���� ���� ȥ�տ��� ������ �����Ƿ�, ���������� ������ ����)
    glm::vec3 eyeColor = glm::vec3(1.0f, 0.0f, 0.0f);
    glm::mat4 lEye = glm::translate(headMat, glm::vec3(-0.15f, 0.0f, 0.31f));
    DrawBox(shaderID, model, glm::scale(lEye, glm::vec3(0.1f, 0.1f, 0.05f)), eyeColor);
    glm::mat4 rEye = glm::translate(headMat, glm::vec3(0.15f, 0.0f, 0.31f));
    DrawBox(shaderID, model, glm::scale(rEye, glm::vec3(0.1f, 0.1f, 0.05f)), eyeColor);

    // 2. ���� (�Ʒ��� ������ ��Ӱ� -> �����ϰ�)
    int tailSegments = 5;
    for (int i = 1; i <= tailSegments; ++i) {
        float t = (float)i / tailSegments;

        float yOffset = 0.8f - (i * 0.25f);
        float wobbleX = sin(wobbleTime + i * 0.5f) * 0.1f;
        float wobbleZ = cos(wobbleTime + i * 0.5f) * 0.1f;

        glm::mat4 tailMat = glm::translate(bodyMat, glm::vec3(wobbleX, yOffset, wobbleZ));
        float scale = 0.5f * (1.0f - t * 0.5f);
        glm::mat4 tailScale = glm::scale(tailMat, glm::vec3(scale, 0.2f, scale));

        glm::vec3 tailColor = baseColor * (1.0f - t * 0.9f); // �Ʒ��� ������ ��ο���
        DrawBox(shaderID, model, tailScale, tailColor);
    }

    // 3. ��
    float armWobble = sin(wobbleTime * 0.8f) * 20.0f;

    glm::mat4 lArmMat = glm::translate(headMat, glm::vec3(-0.4f, -0.2f, 0.0f));
    lArmMat = glm::rotate(lArmMat, glm::radians(40.0f + armWobble), glm::vec3(0.0f, 0.0f, 1.0f));
    DrawBox(shaderID, model, glm::scale(lArmMat, glm::vec3(0.15f, 0.5f, 0.15f)), baseColor * 0.8f);

    glm::mat4 rArmMat = glm::translate(headMat, glm::vec3(0.4f, -0.2f, 0.0f));
    rArmMat = glm::rotate(rArmMat, glm::radians(-40.0f - armWobble), glm::vec3(0.0f, 0.0f, 1.0f));
    DrawBox(shaderID, model, glm::scale(rArmMat, glm::vec3(0.15f, 0.5f, 0.15f)), baseColor * 0.8f);
}

bool IsCollideWithPlayer(const glm::vec3& ghostPos, const glm::vec3& playerPos) {
    float threshold = 0.7f;
    float dx = ghostPos.x - playerPos.x;
    float dz = ghostPos.z - playerPos.z;
    float distSq = dx * dx + dz * dz;
    return distSq < (threshold * threshold);
}

glm::vec3 GetRandomPathPosition(const MazeMap& maze, int mapSize, float baseHeight) {
    std::vector<std::pair<int, int>> pathCells;
    for (int z = 0; z < mapSize; ++z) {
        for (int x = 0; x < mapSize; ++x) {
            if (maze.maze[z * mapSize + x] == 0) {
                pathCells.emplace_back(z, x);
            }
        }
    }
    if (pathCells.empty()) return glm::vec3(0.0f, baseHeight, 0.0f);

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, pathCells.size() - 1);
    auto cell = pathCells[dis(gen)];
    float worldX = cell.second * WALL_SIZE;
    float worldZ = cell.first * WALL_SIZE;
    return glm::vec3(worldX, baseHeight, worldZ);
}

std::vector<std::pair<int, int>> Ghost::FindPath(MazeMap& maze, glm::vec3 startPos, glm::vec3 endPos, int mapSize) {
    int sx = static_cast<int>((startPos.x + WALL_SIZE / 2) / WALL_SIZE);
    int sz = static_cast<int>((startPos.z + WALL_SIZE / 2) / WALL_SIZE);
    int ex = static_cast<int>((endPos.x + WALL_SIZE / 2) / WALL_SIZE);
    int ez = static_cast<int>((endPos.z + WALL_SIZE / 2) / WALL_SIZE);

    std::priority_queue<Node, std::vector<Node>, std::greater<Node>> open;
    std::unordered_map<int, std::pair<int, int>> parent;
    std::vector<std::vector<int>> cost(mapSize, std::vector<int>(mapSize, INT_MAX));
    int dr[4] = { -1, 1, 0, 0 }, dc[4] = { 0, 0, -1, 1 };

    auto heuristic = [&](int r, int c) {
        return abs(r - ez) + abs(c - ex); // ����ư �Ÿ�
        };

    open.push(Node(sz, sx, 0, heuristic(sz, sx)));
    cost[sz][sx] = 0;

    while (!open.empty()) {
        Node node = open.top(); open.pop();
        int r = node.r, c = node.c;
        if (r == ez && c == ex) break;
        for (int d = 0; d < 4; ++d) {
            int nr = r + dr[d], nc = c + dc[d];
            if (nr >= 0 && nr < mapSize && nc >= 0 && nc < mapSize) {
                int cell = maze.mapData[nr][nc];
                if (cell != 0) continue; // ��(0)�� ��� ����
                int moveCost = 1;
                int newCost = cost[r][c] + moveCost;
                if (newCost < cost[nr][nc]) {
                    cost[nr][nc] = newCost;
                    parent[nr * mapSize + nc] = { r, c };
                    open.push(Node(nr, nc, newCost, newCost + heuristic(nr, nc)));
                }
            }
        }
    }

    // ��� ������
    std::vector<std::pair<int, int>> path;
    int r = ez, c = ex;
    while (!(r == sz && c == sx)) {
        path.push_back({ r, c });
        auto it = parent.find(r * mapSize + c);
        if (it == parent.end()) break;
        r = it->second.first;
        c = it->second.second;
    }
    std::reverse(path.begin(), path.end());
    return path;
}
